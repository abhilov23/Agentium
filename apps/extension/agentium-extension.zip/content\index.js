"use strict";
(() => {
  // src/shared/errors.ts
  function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
  }

  // src/shared/request-id.ts
  function requestIdOf(value) {
    if (typeof value === "object" && value !== null && "id" in value) {
      const id = value.id;
      if (typeof id === "string" && id.length > 0) return id;
    }
    return "unknown";
  }

  // src/content/extraction.ts
  function extractContent(options) {
    return options.format === "links" ? extractLinks(options.maxItems ?? 100) : extractText(options.maxChars ?? 8e3);
  }
  function extractText(maxChars) {
    const root = document.querySelector("main, article") ?? document.body;
    if (!root) {
      return { url: location.href, title: document.title, format: "text", text: "", truncated: false };
    }
    const raw = root instanceof HTMLElement ? root.innerText : root.textContent ?? "";
    const text = raw.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
    return {
      url: location.href,
      title: document.title,
      format: "text",
      text: text.slice(0, maxChars),
      truncated: text.length > maxChars
    };
  }
  function extractLinks(maxItems) {
    const seen = /* @__PURE__ */ new Set();
    const links = [];
    let found = 0;
    for (const anchor of Array.from(document.querySelectorAll("a[href]"))) {
      if (!anchor.href) continue;
      if (!anchor.href.startsWith("http://") && !anchor.href.startsWith("https://")) continue;
      if (seen.has(anchor.href)) continue;
      seen.add(anchor.href);
      found += 1;
      if (links.length < maxItems) {
        const text = (anchor.innerText || anchor.textContent || anchor.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
        links.push({ text, href: anchor.href });
      }
    }
    return {
      url: location.href,
      title: document.title,
      format: "links",
      links,
      truncated: found > links.length
    };
  }

  // src/content/dom.ts
  var INTERACTIVE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type='hidden'])",
    "textarea",
    "select",
    "form",
    "h1",
    "h2",
    "h3",
    "[role='button']",
    "[role='link']",
    "[role='textbox']",
    "[contenteditable='']",
    "[contenteditable='true']"
  ].join(", ");
  function clean(value) {
    return (value ?? "").replace(/\s+/g, " ").trim();
  }
  function shorten(value, maxLength = 120) {
    return value.length <= maxLength ? value : `${value.slice(0, maxLength - 1)}\u2026`;
  }
  function isVisible(element) {
    if (element.closest("[hidden], [aria-hidden='true']")) return false;
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  function elementKind(element) {
    if (element instanceof HTMLAnchorElement) return "link";
    if (element instanceof HTMLButtonElement) return "button";
    if (element instanceof HTMLTextAreaElement) return "textarea";
    if (element instanceof HTMLSelectElement) return "select";
    if (element instanceof HTMLFormElement) return "form";
    if (element instanceof HTMLHeadingElement) return "heading";
    if (element instanceof HTMLInputElement) {
      return element.type === "submit" || element.type === "button" || element.type === "reset" ? "button" : "input";
    }
    if (element instanceof HTMLElement && element.isContentEditable) return "editable";
    return "interactive";
  }
  function accessibleName(element) {
    const labelledBy = element.getAttribute("aria-labelledby");
    if (labelledBy) {
      const label = labelledBy.split(/\s+/).map((id) => document.getElementById(id)?.textContent ?? "").join(" ");
      const cleaned = clean(label);
      if (cleaned) return shorten(cleaned);
    }
    const ariaLabel = clean(element.getAttribute("aria-label"));
    if (ariaLabel) return shorten(ariaLabel);
    if (element instanceof HTMLFormElement) {
      const label = clean(element.getAttribute("name") ?? element.getAttribute("id") ?? element.getAttribute("title"));
      if (label) return shorten(label);
    }
    const labels = element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement ? element.labels : null;
    if (labels && labels.length > 0) {
      const label = clean(Array.from(labels).map((item) => item.textContent).join(" "));
      if (label) return shorten(label);
    }
    if (element instanceof HTMLInputElement) {
      if (element.type === "submit" || element.type === "button" || element.type === "reset") {
        const value = clean(element.value);
        if (value) return shorten(value);
      }
      const hint = clean(element.placeholder) || clean(element.title);
      if (hint) return shorten(hint);
      const name = clean(element.name) || clean(element.id);
      if (name) return shorten(name);
    }
    if (element instanceof HTMLTextAreaElement) {
      const hint = clean(element.placeholder) || clean(element.title);
      if (hint) return shorten(hint);
      const name = clean(element.name) || clean(element.id);
      if (name) return shorten(name);
    }
    if (element instanceof HTMLSelectElement) {
      const name = clean(element.name) || clean(element.id) || clean(element.title);
      if (name) return shorten(name);
    }
    const image = element.querySelector("img[alt]");
    const alt = clean(image?.getAttribute("alt"));
    if (alt) return shorten(alt);
    const text = element.innerText || element.textContent || element.getAttribute("title") || "";
    return shorten(clean(text));
  }

  // src/content/inspection.ts
  function hasSensitiveValue(element) {
    if (element.type === "password" || element.type === "file") return true;
    return /(?:password|one-time-code|cc-)/i.test(element.autocomplete);
  }
  function inspectPage(registry2, maxElements = 120) {
    const limit = Math.min(Math.max(maxElements, 1), 300);
    const candidates = Array.from(document.querySelectorAll(INTERACTIVE_SELECTOR)).filter((element) => isVisible(element));
    const elements = [];
    for (const element of candidates) {
      if (elements.length >= limit) break;
      const ref = registry2.register(element);
      const kind = elementKind(element);
      const info = {
        ref,
        kind,
        tag: element.tagName.toLowerCase(),
        name: accessibleName(element)
      };
      const role = clean(element.getAttribute("role"));
      if (role) info.role = role;
      if (element instanceof HTMLAnchorElement && element.href) {
        info.href = shorten(element.href, 300);
      }
      if (element instanceof HTMLInputElement) {
        if (kind === "input") {
          info.inputType = element.type;
          if (!hasSensitiveValue(element) && element.value) info.value = shorten(element.value, 200);
        }
        if (element.placeholder) info.placeholder = shorten(clean(element.placeholder));
        if (element.checked) info.checked = true;
        if (element.disabled) info.disabled = true;
      }
      if (element instanceof HTMLTextAreaElement) {
        if (element.placeholder) info.placeholder = shorten(clean(element.placeholder));
        if (element.disabled) info.disabled = true;
      }
      if (element instanceof HTMLSelectElement) {
        if (element.value) info.value = shorten(element.value, 200);
        if (element.disabled) info.disabled = true;
      }
      if (element instanceof HTMLHeadingElement) {
        info.level = Number(element.tagName.slice(1));
      }
      elements.push(info);
    }
    return {
      url: location.href,
      title: document.title,
      total: candidates.length,
      returned: elements.length,
      truncated: elements.length < candidates.length,
      elements
    };
  }

  // src/content/interaction.ts
  var UNSUPPORTED_INPUT_TYPES = ["button", "checkbox", "file", "hidden", "image", "radio", "reset", "submit"];
  function isDisabled(element) {
    return element.matches(":disabled, [aria-disabled='true']");
  }
  function prepareElementClick(registry2, ref) {
    const element = registry2.resolve(ref);
    if (!isVisible(element)) {
      throw new Error(`Element ${ref} is not visible. Inspect the page again for visible elements.`);
    }
    if (isDisabled(element)) {
      throw new Error(`Element ${ref} is disabled and cannot be clicked.`);
    }
    element.scrollIntoView({ block: "center", inline: "center" });
    const rect = element.getBoundingClientRect();
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2,
      url: location.href,
      title: document.title
    };
  }
  function scrollPage(payload) {
    const behavior = payload.behavior ?? "auto";
    if (payload.direction) {
      const step = Math.max(window.innerHeight * 0.6, 200);
      switch (payload.direction) {
        case "top":
          window.scrollTo({ top: 0, left: 0, behavior });
          return { x: window.scrollX, y: window.scrollY };
        case "bottom":
          window.scrollTo({ top: document.body.scrollHeight, left: document.body.scrollWidth, behavior });
          return { x: window.scrollX, y: window.scrollY };
        case "up":
          window.scrollBy({ top: -step, left: 0, behavior });
          return { x: window.scrollX, y: window.scrollY };
        case "down":
          window.scrollBy({ top: step, left: 0, behavior });
          return { x: window.scrollX, y: window.scrollY };
        case "left":
          window.scrollBy({ top: 0, left: -step, behavior });
          return { x: window.scrollX, y: window.scrollY };
        case "right":
          window.scrollBy({ top: 0, left: step, behavior });
          return { x: window.scrollX, y: window.scrollY };
        default:
          break;
      }
    }
    const nextX = payload.x ?? window.scrollX;
    const nextY = payload.y ?? window.scrollY;
    window.scrollTo({ left: nextX, top: nextY, behavior });
    return { x: window.scrollX, y: window.scrollY };
  }
  function hoverElement(registry2, ref) {
    const element = registry2.resolve(ref);
    if (!isVisible(element)) {
      throw new Error(`Element ${ref} is not visible. Inspect the page again for visible elements.`);
    }
    element.scrollIntoView({ block: "center", inline: "center" });
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    element.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true, clientX: x, clientY: y }));
    element.dispatchEvent(new MouseEvent("mouseover", { bubbles: true, clientX: x, clientY: y }));
    element.dispatchEvent(new MouseEvent("mousemove", { bubbles: true, clientX: x, clientY: y }));
    return { x: Math.round(window.scrollX + x), y: Math.round(window.scrollY + y) };
  }
  function waitForSelector(selector, timeoutMs = 1e4, visibleOnly = false) {
    return new Promise((resolve) => {
      const startedAt = Date.now();
      const tick = () => {
        const match = document.querySelector(selector);
        if (match) {
          const visible = !visibleOnly || isVisible(match);
          if (visible) {
            resolve({ selector, found: true, visible: true, url: location.href, title: document.title });
            return;
          }
        }
        if (Date.now() - startedAt >= timeoutMs) {
          resolve({ selector, found: false, visible: false, url: location.href, title: document.title });
          return;
        }
        setTimeout(tick, 100);
      };
      tick();
    });
  }
  function getPageState() {
    return {
      url: location.href,
      title: document.title,
      readyState: document.readyState,
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight
      },
      isInteractive: document.readyState === "interactive" || document.readyState === "complete"
    };
  }
  function waitForNetworkIdle(timeoutMs = 15e3, idleMs = 500) {
    const startedAt = Date.now();
    let lastMutationAt = Date.now();
    const observer = new MutationObserver(() => {
      lastMutationAt = Date.now();
    });
    observer.observe(document.body || document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true
    });
    return new Promise((resolve) => {
      const check = () => {
        const elapsedMs = Date.now() - startedAt;
        const sinceMutation = Date.now() - lastMutationAt;
        const idle = sinceMutation >= idleMs;
        if (idle || elapsedMs >= timeoutMs) {
          observer.disconnect();
          const waitedMs = Date.now() - startedAt;
          resolve({
            url: location.href,
            title: document.title,
            idle,
            elapsedMs,
            waitedMs
          });
          return;
        }
        setTimeout(check, 100);
      };
      check();
    });
  }
  function findText(query, exact = false, maxMatches = 10) {
    const normalizedQuery = query.trim();
    const limit = Math.max(1, Math.min(maxMatches, 50));
    const matches = [];
    const walk = (node, callback) => {
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      const element = node;
      callback(element);
      element.childNodes.forEach((child) => walk(child, callback));
    };
    const matcher = (text) => {
      const value = text.trim();
      if (!value) return false;
      if (exact) return value.toLowerCase() === normalizedQuery.toLowerCase();
      return value.toLowerCase().includes(normalizedQuery.toLowerCase());
    };
    const visited = /* @__PURE__ */ new Set();
    walk(document.body, (element) => {
      if (visited.has(element)) return;
      visited.add(element);
      if (!(element instanceof HTMLElement)) return;
      const textContent = element.textContent ?? "";
      const directText = textContent.trim();
      if (!directText || !matcher(directText)) return;
      if (matches.length >= limit) return;
      const selector = element.tagName.toLowerCase();
      const match = {
        text: directText,
        tag: element.tagName.toLowerCase(),
        selector
      };
      if (element instanceof HTMLAnchorElement && element.href) match.href = element.href;
      const role = element.getAttribute("role");
      if (role) match.role = role;
      matches.push(match);
    });
    return {
      query: normalizedQuery,
      matches,
      total: matches.length,
      truncated: matches.length >= limit,
      url: location.href,
      title: document.title
    };
  }
  function typeElement(registry2, ref, text, submit = false) {
    const element = registry2.resolve(ref);
    if (!isVisible(element)) {
      throw new Error(`Element ${ref} is not visible. Inspect the page again for visible elements.`);
    }
    if (isDisabled(element)) {
      throw new Error(`Element ${ref} is disabled and cannot receive typed text.`);
    }
    if (element instanceof HTMLInputElement) {
      if (UNSUPPORTED_INPUT_TYPES.includes(element.type)) {
        throw new Error(`Element ${ref} is a ${element.type} input and does not accept typed text.`);
      }
      element.focus();
      setNativeValue(element, text);
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      if (submit) submitFrom(element);
    } else if (element instanceof HTMLTextAreaElement) {
      element.focus();
      setNativeValue(element, text);
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      if (submit) submitFrom(element);
    } else if (element instanceof HTMLElement && element.isContentEditable) {
      element.focus();
      element.textContent = text;
      element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      if (submit) {
        const form = element.closest("form");
        if (form instanceof HTMLFormElement) form.requestSubmit();
        else pressEnter(element);
      }
    } else {
      throw new Error(`Element ${ref} cannot accept typed text. Inspect the page to find an input, textarea, or editable region.`);
    }
    return { url: location.href, title: document.title };
  }
  function handleDialog(type, accept = true, promptText) {
    window.alert = (() => void 0);
    window.confirm = (() => accept);
    window.prompt = (() => accept ? promptText ?? "" : null);
    return {
      type,
      accepted: accept,
      value: type === "prompt" ? accept ? promptText ?? null : null : null,
      url: location.href,
      title: document.title
    };
  }
  function fillForm(fields) {
    let submitted = false;
    const processed = fields.map((field) => {
      const node = document.querySelector(field.selector);
      if (!node) {
        throw new Error(`Selector not found: ${field.selector}`);
      }
      const element = node;
      if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement) {
        const value = field.clear ? "" : field.value;
        if (element instanceof HTMLSelectElement) {
          const option = Array.from(element.options).find((option2) => option2.value === value || option2.text === value);
          if (option) {
            element.value = option.value;
            element.dispatchEvent(new Event("change", { bubbles: true }));
          }
        } else {
          const prototype = element instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
          const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
          if (setter) setter.call(element, value);
          else element.value = value;
          element.dispatchEvent(new Event("input", { bubbles: true }));
          element.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } else if (element.isContentEditable) {
        element.textContent = field.value;
        element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: field.value }));
      } else {
        throw new Error(`Selector ${field.selector} is not a supported form field.`);
      }
      if (field.submit) {
        const form = element.closest("form");
        if (form instanceof HTMLFormElement) {
          form.requestSubmit();
          submitted = true;
        } else {
          element.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }));
          submitted = true;
        }
      }
      return field;
    });
    return {
      url: location.href,
      title: document.title,
      submitted,
      fieldCount: processed.length
    };
  }
  async function evaluateJs(script) {
    try {
      const value = await Function(`"use strict"; return (${script});`)();
      const result = typeof value === "string" ? value : typeof value === "undefined" ? null : (() => {
        try {
          return JSON.parse(JSON.stringify(value, (_key, item) => typeof item === "bigint" ? item.toString() : item));
        } catch {
          return String(value);
        }
      })();
      return { url: location.href, title: document.title, result };
    } catch (error) {
      throw new Error(`Could not evaluate script: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  function uploadFile(registry2, ref, fileName, contentBase64, mimeType) {
    const element = registry2.resolve(ref);
    if (!(element instanceof HTMLInputElement)) {
      throw new Error(`Element ${ref} is not a file input.`);
    }
    if (element.type !== "file") {
      throw new Error(`Element ${ref} is not a file input element.`);
    }
    if (!isVisible(element)) {
      throw new Error(`Element ${ref} is not visible. Inspect the page again for visible elements.`);
    }
    const binary = Uint8Array.from(atob(contentBase64), (char) => char.charCodeAt(0));
    const blob = new Blob([binary], { type: mimeType ?? "application/octet-stream" });
    const resolvedType = mimeType ?? blob.type;
    const file = new File([blob], fileName, { type: resolvedType || "application/octet-stream" });
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    element.files = dataTransfer.files;
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    return { url: location.href, title: document.title, filename: file.name, mimeType: file.type };
  }
  function submitFrom(element) {
    if (element.form) {
      element.form.requestSubmit();
      return;
    }
    pressEnter(element);
  }
  function pressEnter(element) {
    for (const type of ["keydown", "keypress", "keyup"]) {
      element.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
    }
  }
  function setNativeValue(element, value) {
    const prototype = element instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (setter) setter.call(element, value);
    else element.value = value;
  }

  // src/content/refs.ts
  var ElementRegistry = class {
    elementsByRef = /* @__PURE__ */ new Map();
    refsByElement = /* @__PURE__ */ new WeakMap();
    nextRef = 1;
    // Return a stable ref for this element, creating one if needed.
    register(element) {
      const existing = this.refsByElement.get(element);
      if (existing) return existing;
      const ref = `e${this.nextRef}`;
      this.nextRef += 1;
      this.refsByElement.set(element, ref);
      this.elementsByRef.set(ref, element);
      return ref;
    }
    // Find the element for a ref and reject stale refs.
    resolve(ref) {
      const element = this.elementsByRef.get(ref);
      if (!element) {
        throw new Error(`Unknown element reference ${ref}. Inspect the page again to obtain fresh references.`);
      }
      if (!element.isConnected) {
        this.elementsByRef.delete(ref);
        throw new Error(`Element ${ref} is no longer on the page. Inspect the page again.`);
      }
      return element;
    }
  };

  // src/content/validation.ts
  var REF_PATTERN = /^e\d+$/;
  function parsePageRequest(value) {
    if (!isRecord(value)) return null;
    const { id, action, payload } = value;
    if (typeof id !== "string" || id.length === 0) return null;
    if (!isRecord(payload)) return null;
    switch (action) {
      case "PING":
        return { id, action, payload: {} };
      case "INSPECT_PAGE": {
        const maxElements = payload.maxElements;
        if (maxElements !== void 0 && !isBoundedInteger(maxElements, 1, 300)) return null;
        return maxElements === void 0 ? { id, action, payload: {} } : { id, action, payload: { maxElements } };
      }
      case "PREPARE_CLICK": {
        const ref = payload.ref;
        if (typeof ref !== "string" || !REF_PATTERN.test(ref)) return null;
        return { id, action, payload: { ref } };
      }
      case "TYPE_ELEMENT": {
        const ref = payload.ref;
        const text = payload.text;
        const submit = payload.submit;
        if (typeof ref !== "string" || !REF_PATTERN.test(ref)) return null;
        if (typeof text !== "string" || text.length > 2e4) return null;
        if (submit !== void 0 && typeof submit !== "boolean") return null;
        return submit === void 0 ? { id, action, payload: { ref, text } } : { id, action, payload: { ref, text, submit } };
      }
      case "HANDLE_DIALOG": {
        const type = payload.type;
        const accept = payload.accept;
        const promptText = payload.promptText;
        if (type !== "alert" && type !== "confirm" && type !== "prompt") return null;
        if (accept !== void 0 && typeof accept !== "boolean") return null;
        if (promptText !== void 0 && (typeof promptText !== "string" || promptText.length > 2048)) return null;
        return {
          id,
          action,
          payload: {
            type,
            ...accept !== void 0 ? { accept } : {},
            ...promptText !== void 0 ? { promptText } : {}
          }
        };
      }
      case "FILL_FORM": {
        const fields = payload.fields;
        if (!Array.isArray(fields) || fields.length === 0 || fields.length > 50) return null;
        const parsedFields = [];
        for (const field of fields) {
          if (!isRecord(field)) return null;
          const selector = field.selector;
          const value2 = field.value;
          const clear = field.clear;
          const submit = field.submit;
          if (typeof selector !== "string" || selector.length === 0 || selector.length > 2048) return null;
          if (typeof value2 !== "string" || value2.length > 2e4) return null;
          if (clear !== void 0 && typeof clear !== "boolean") return null;
          if (submit !== void 0 && typeof submit !== "boolean") return null;
          parsedFields.push({ selector, value: value2, ...clear !== void 0 ? { clear } : {}, ...submit !== void 0 ? { submit } : {} });
        }
        return { id, action, payload: { fields: parsedFields } };
      }
      case "EVALUATE_JS": {
        const script = payload.script;
        if (typeof script !== "string" || script.length === 0 || script.length > 5e4) return null;
        return { id, action, payload: { script } };
      }
      case "UPLOAD_FILE": {
        const ref = payload.ref;
        const fileName = payload.fileName;
        const contentBase64 = payload.contentBase64;
        const mimeType = payload.mimeType;
        if (typeof ref !== "string" || !REF_PATTERN.test(ref)) return null;
        if (typeof fileName !== "string" || fileName.length === 0 || fileName.length > 255) return null;
        if (typeof contentBase64 !== "string" || contentBase64.length === 0 || contentBase64.length > 5e6) return null;
        if (mimeType !== void 0 && (typeof mimeType !== "string" || mimeType.length > 128)) return null;
        return { id, action, payload: { ref, fileName, contentBase64, ...mimeType !== void 0 ? { mimeType } : {} } };
      }
      case "WAIT_FOR_SELECTOR": {
        const selector = payload.selector;
        const timeoutMs = payload.timeoutMs;
        const visibleOnly = payload.visibleOnly;
        if (typeof selector !== "string" || selector.length === 0 || selector.length > 2048) return null;
        if (timeoutMs !== void 0 && !isBoundedInteger(timeoutMs, 100, 6e4)) return null;
        if (visibleOnly !== void 0 && typeof visibleOnly !== "boolean") return null;
        const parsedPayload = { selector };
        if (timeoutMs !== void 0) parsedPayload.timeoutMs = timeoutMs;
        if (visibleOnly !== void 0) parsedPayload.visibleOnly = visibleOnly;
        return { id, action, payload: parsedPayload };
      }
      case "GET_PAGE_STATE":
        return { id, action, payload: {} };
      case "WAIT_FOR_NETWORK_IDLE": {
        const timeoutMs = payload.timeoutMs;
        const idleMs = payload.idleMs;
        if (timeoutMs !== void 0 && !isBoundedInteger(timeoutMs, 100, 6e4)) return null;
        if (idleMs !== void 0 && !isBoundedInteger(idleMs, 100, 1e4)) return null;
        const parsedPayload = {};
        if (timeoutMs !== void 0) parsedPayload.timeoutMs = timeoutMs;
        if (idleMs !== void 0) parsedPayload.idleMs = idleMs;
        return { id, action, payload: parsedPayload };
      }
      case "FIND_TEXT": {
        const query = payload.query;
        const exact = payload.exact;
        const maxMatches = payload.maxMatches;
        if (typeof query !== "string" || query.length === 0 || query.length > 2048) return null;
        if (exact !== void 0 && typeof exact !== "boolean") return null;
        if (maxMatches !== void 0 && !isBoundedInteger(maxMatches, 1, 50)) return null;
        const parsedPayload = { query };
        if (exact !== void 0) parsedPayload.exact = exact;
        if (maxMatches !== void 0) parsedPayload.maxMatches = maxMatches;
        return { id, action, payload: parsedPayload };
      }
      case "EXTRACT_CONTENT": {
        const format = payload.format;
        const maxChars = payload.maxChars;
        const maxItems = payload.maxItems;
        if (format !== void 0 && format !== "text" && format !== "links") return null;
        if (maxChars !== void 0 && !isBoundedInteger(maxChars, 100, 5e4)) return null;
        if (maxItems !== void 0 && !isBoundedInteger(maxItems, 1, 500)) return null;
        const parsedPayload = {};
        if (format !== void 0) parsedPayload.format = format;
        if (maxChars !== void 0) parsedPayload.maxChars = maxChars;
        if (maxItems !== void 0) parsedPayload.maxItems = maxItems;
        return { id, action, payload: parsedPayload };
      }
      default:
        return null;
    }
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isBoundedInteger(value, min, max) {
    return typeof value === "number" && Number.isInteger(value) && value >= min && value <= max;
  }

  // src/content/index.ts
  var registry = new ElementRegistry();
  function handleRequest(request) {
    switch (request.action) {
      case "PING":
        return { ready: true };
      case "INSPECT_PAGE":
        return inspectPage(registry, request.payload.maxElements);
      case "PREPARE_CLICK":
        return prepareElementClick(registry, request.payload.ref);
      case "TYPE_ELEMENT":
        return typeElement(registry, request.payload.ref, request.payload.text, request.payload.submit);
      case "HANDLE_DIALOG":
        return handleDialog(request.payload.type, request.payload.accept, request.payload.promptText);
      case "FILL_FORM":
        return fillForm(request.payload.fields);
      case "EVALUATE_JS":
        return evaluateJs(request.payload.script);
      case "UPLOAD_FILE":
        return uploadFile(registry, request.payload.ref, request.payload.fileName, request.payload.contentBase64, request.payload.mimeType);
      case "SCROLL_PAGE":
        return scrollPage(request.payload);
      case "HOVER_ELEMENT":
        return hoverElement(registry, request.payload.ref);
      case "WAIT_FOR_SELECTOR":
        return waitForSelector(request.payload.selector, request.payload.timeoutMs, request.payload.visibleOnly);
      case "GET_PAGE_STATE":
        return getPageState();
      case "WAIT_FOR_NETWORK_IDLE":
        return waitForNetworkIdle(request.payload.timeoutMs, request.payload.idleMs);
      case "FIND_TEXT":
        return findText(request.payload.query, request.payload.exact, request.payload.maxMatches);
      case "EXTRACT_CONTENT":
        return extractContent(request.payload);
    }
  }
  if (!window.__foundryLensContentLoaded) {
    window.__foundryLensContentLoaded = true;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      const request = parsePageRequest(message);
      if (!request) {
        sendResponse({ id: requestIdOf(message), success: false, error: "Invalid page request." });
        return false;
      }
      void Promise.resolve().then(() => handleRequest(request)).then((data) => sendResponse({ id: request.id, success: true, data })).catch(
        (error) => sendResponse({ id: request.id, success: false, error: errorMessage(error) })
      );
      return true;
    });
  }
})();
//# sourceMappingURL=index.js.map
